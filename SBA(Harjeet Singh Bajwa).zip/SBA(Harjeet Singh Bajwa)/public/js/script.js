function getJoke(){
	fetch('https://api.chucknorris.io/jokes/random')
  .then((response) => {
    return response.json()
  })
  .then((data) => {
    // Work with JSON data here
    let container2 = document.querySelector('.container');
    container2.innerHTML = "Chuck Norris Jokes";
	joke.innerHTML = data.value;
	picture.innerHTML = '<img src="'+data.icon_url+'">';
  })
  .catch((err) => {
    // Do something for an error here
	let html = 'error';
    let container = document.querySelector('.container');
    container.innerHTML = html;
  })
}





function CreateTableFromJSON() {
	
	
	fetch('https://gist.githubusercontent.com/harjeet-dot/7b39fc46ace0d5d00096c24b8baff149/raw/b34df632e0a1da048e30ffe7fd66c8035298aad1/aaa.json')
  .then((response) => {
    return response.json()
  })
  .then((data) => {
    // Work with JSON data here
	
	    // EXTRACT VALUE FOR HTML HEADER. 
        var col = [];
        for (var i = 0; i < data.length; i++) {
            for (var key in data[i]) {
                if (col.indexOf(key) === -1) {
                    col.push(key);
                }
            }
        }
	
	    // CREATE DYNAMIC TABLE.
        var table = document.createElement("table");
		
		
		// CREATE HTML TABLE HEADER ROW USING THE EXTRACTED HEADERS ABOVE.
        var tr = table.insertRow(-1);                   // TABLE ROW.

        for (var i = 0; i < col.length; i++) {
            var th = document.createElement("th");      // TABLE HEADER.
            th.innerHTML = col[i];
            tr.appendChild(th);
        }
		
		// ADD JSON DATA TO THE TABLE AS ROWS.
        for (var i = 0; i < data.length; i++) {

            tr = table.insertRow(-1);

            for (var j = 0; j < col.length; j++) {
                var tabCell = tr.insertCell(-1);
				if (j < 2){
                tabCell.innerHTML = data[i][col[j]];	
				}
				else{
				tabCell.innerHTML = '<img src="'+data[i].Image+'">';
				}
            }
        }
		
		// FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
        var divContainer = document.getElementById("showData");
        divContainer.innerHTML = "";
        divContainer.appendChild(table);	
  })
  .catch((err) => {
    // Do something for an error here
	let html = 'error';
    let container = document.querySelector('.container');
    container.innerHTML = html;
  })
  }


